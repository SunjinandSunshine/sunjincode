package version3;

import javax.swing.*;

public class DisplayMinimunSpanningTree extends JApplet{
	private static final long serialVersionUID = 1L;

	public DisplayMinimunSpanningTree() {
		add(new MinimunSpanningTreeControl());
	}
	
	@Override
	public void init() {
		this.setSize(1200,800);
	}
}