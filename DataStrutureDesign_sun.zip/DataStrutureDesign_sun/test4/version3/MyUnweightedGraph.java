package version3;

import java.util.*;

public class MyUnweightedGraph<V> extends MyAbstractGraph<V>{
	public MyUnweightedGraph(int[][] edges, V[] vertices){
		super(edges, vertices);
	}
	
	public MyUnweightedGraph(List<Edge> edges,  List<V> vertices){
		super(edges, vertices);
	}
	
	public MyUnweightedGraph(List<Edge> edges, int numberOfVertices)	{
		super(edges, numberOfVertices);
	}
	
	public  MyUnweightedGraph(int[][] edges, int numberOfVertices){
		super(edges, numberOfVertices);
	}

	public int[][] getAdjacenyMatrix() {
		return null;
	}
}
