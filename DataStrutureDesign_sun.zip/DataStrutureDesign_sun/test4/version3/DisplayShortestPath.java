package version3;

import javax.swing.JApplet;

public class DisplayShortestPath extends JApplet{
	private static final long serialVersionUID = 1L;

	public DisplayShortestPath() {
		add(new ShortestPathControl());
	}
	
	@Override
	public void init() {
		this.setSize(800,500);
	}
}