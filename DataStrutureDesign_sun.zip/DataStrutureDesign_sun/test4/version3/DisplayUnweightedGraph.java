package version3;

import javax.swing.JApplet;

public class DisplayUnweightedGraph extends JApplet{
	private static final long serialVersionUID = 1L;

	public DisplayUnweightedGraph() {
		add(new UnweightedControl());
	}
	
	@Override
	public void init() {
		this.setSize(800,500);
	}
}