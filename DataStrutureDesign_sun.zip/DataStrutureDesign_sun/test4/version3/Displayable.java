package version3;

public interface Displayable {
	public int getX();
	public int getY();
	public String getName();
}
