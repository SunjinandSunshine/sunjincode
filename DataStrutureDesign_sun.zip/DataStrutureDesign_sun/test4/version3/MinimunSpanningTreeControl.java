package version3;

import java.util.List;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import version3.WeightedGraph.MST;

import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class MinimunSpanningTreeControl extends JPanel {
	// ���ý������
	private JTextField jtfVertexName;
	private JTextField jtfX;
	private JTextField jtfY;
	private JButton jbtAddVertex;
	private JTextField jtfu;
	private JTextField jtfv;
	private JTextField jtfWeight;
	private JButton jbtAddEdge;

	// ��������
	private WeightedGraph<Vertex> graph;
	private GraphView view;

	/** ���캯�� */
	public MinimunSpanningTreeControl() {
		this.setLayout(new BorderLayout());

		// �������
		jtfVertexName = new JTextField(5);
		jtfX = new JTextField(5);
		jtfY = new JTextField(5);
		jbtAddVertex = new JButton("Add Vertex");
		jtfu = new JTextField(5);
		jtfv = new JTextField(5);
		jtfWeight = new JTextField(5);
		jbtAddEdge = new JButton("Add Edge");
		graph = new WeightedGraph<Vertex>();
		view = new GraphView(graph);

		// �������
		JPanel vertexPanel = new JPanel(new GridLayout(4, 2));
		vertexPanel.add(new JLabel("Vertex name "));
		vertexPanel.add(jtfVertexName);
		vertexPanel.add(new JLabel("x-coordinate:"));
		vertexPanel.add(jtfX);
		vertexPanel.add(new JLabel("y-coordinate:"));
		vertexPanel.add(jtfY);
		vertexPanel.add(new JLabel());
		vertexPanel.add(jbtAddVertex);
		vertexPanel.setBorder(new TitledBorder("Add a new vertex"));

		JPanel edgePanel = new JPanel(new GridLayout(4, 3));
		edgePanel.add(new JLabel("Vertex u(index): "));
		edgePanel.add(jtfu);
		edgePanel.add(new JLabel("Vertex v(index): "));
		edgePanel.add(jtfv);
		edgePanel.add(new JLabel("Weight(int)"));
		edgePanel.add(jtfWeight);
		edgePanel.add(new JLabel(""));
		edgePanel.add(jbtAddEdge);

		edgePanel.setBorder(new TitledBorder("Add a new edge"));

		JPanel combPanel = new JPanel(new GridLayout(1, 2));
		combPanel.add(vertexPanel);
		combPanel.add(edgePanel);

		add(new JScrollPane(view), BorderLayout.CENTER);
		add(combPanel, BorderLayout.SOUTH);

		jbtAddVertex.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// ��ȡ��ǰ���������
					String name = jtfVertexName.getText();
					if (graph.getSize() != Integer.parseInt(name.trim()))
						JOptionPane.showMessageDialog(null, "�������");
					else {
						// ��ȡ�ö����X��Y����
						int x = Integer.parseInt(jtfX.getText().trim());
						int y = Integer.parseInt(jtfY.getText().trim());

						// ���ö������ӵ�ͼ��
						graph.addVertex(new Vertex(name, x, y));
						// �ػ�
						view.repaint();
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "������±������һ��������");
				}
			}
		});
		jbtAddEdge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// ��ȡ���������ֵ��Ȩ��ֵ
					int u = Integer.parseInt(jtfu.getText().trim());
					int v = Integer.parseInt(jtfv.getText().trim());
					int weight = Integer.parseInt(jtfWeight.getText().trim());

					if (u < 0 || u >= graph.getSize())
						JOptionPane.showMessageDialog(null, "���� " + u + "����ͼ�У�");
					else if (v < 0 || v >= graph.getSize())
						JOptionPane.showMessageDialog(null, "���� " + v + " ����ͼ��");
					else if (u == v)
						JOptionPane.showMessageDialog(null, "��������������㲻����ͬ��");
					else {
						// �����������ӵ�ͼ��
						graph.addEdge(u, v, weight);
						view.setMST(graph.getMinimumSpanningTree());
						view.repaint();
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "�������󣡱�����һ��������");
				}
			}
		});
	}

	class Vertex implements Displayable {
		// �����x��y�����Լ�������
		private int x, y;
		private String name;

		Vertex(String name, int x, int y) {
			this.name = name;
			this.x = x;
			this.y = y;
		}

		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

		public String getName() {
			return name;
		}

		public boolean equals(Object o) {
			return ((Vertex) o).name.equals(this.name);
		}
	}
}

class GraphView extends JPanel {
	private static final long serialVersionUID = 1L;
	MyGraph<? extends Displayable> graph;
	List<? extends Displayable> path;
	@SuppressWarnings("rawtypes")
	MST mst;
	@SuppressWarnings("rawtypes")
	List vertices;

	public GraphView(MyGraph<? extends Displayable> graph, List<? extends Displayable> path) {
		this.graph = graph;
		this.path = path;
	}

	public GraphView(MyGraph<? extends Displayable> graph) {
		this.graph = graph;
	}

	public void setPath(List<? extends Displayable> path) {
		this.path = path;
		repaint();
	}
	
	@SuppressWarnings("rawtypes")
	public void setMST(MST mst){
		this.mst = mst;
	}

	@SuppressWarnings("unchecked")
	protected void paintComponent(java.awt.Graphics g) {
		super.paintComponent(g);

		// Draw vertices
		List<? extends Displayable> vertices = graph.getVertices();

		for (int i = 0; i < graph.getSize(); i++) {
			int x = vertices.get(i).getX();
			int y = vertices.get(i).getY();
			String name = vertices.get(i).getName();

			g.fillOval(x - 8, y - 8, 16, 16);
			g.drawString(name, x - 12, y - 12);
		}

		// Draw edges
		for (int i = 0; i < graph.getSize(); i++) {
			List<Integer> neighbors = graph.getNeighbors(i);
			for (int j = 0; j < neighbors.size(); j++) {
				int v = neighbors.get(j);
				int x1 = graph.getVertex(i).getX();
				int y1 = graph.getVertex(i).getY();
				int x2 = graph.getVertex(v).getX();
				int y2 = graph.getVertex(v).getY();

				g.drawLine(x1, y1, x2, y2);
			}
		}

		// Display weights
		List<PriorityQueue<WeightedEdge>> queues = ((WeightedGraph<? extends Displayable>) graph).getWeightedEdges();

		for (int i = 0; i < graph.getSize(); i++) {
			ArrayList<WeightedEdge> list = new ArrayList<WeightedEdge>(queues.get(i));

			for (WeightedEdge edge : list) {
				int u = edge.u;
				int v = edge.v;
				int weight = edge.weight;
				int x1 = graph.getVertex(u).getX();
				int y1 = graph.getVertex(u).getY();
				int x2 = graph.getVertex(v).getX();
				int y2 = graph.getVertex(v).getY();
				g.drawString(weight + "", (x1 + x2) / 2, (y1 + y2) / 2 - 6);
			}
		}

		// Display the path
		if (mst == null)
			return;
		g.setColor(Color.RED);
		vertices = mst.getVertices();
		int[] parent = mst.getParents();
		
		for (int i = 0;i < mst.getParentLength(); i++) {
			if (parent[i] != -1) {
				int x1 = vertices.get(parent[i]).getX();
				int y1 = vertices.get(parent[i]).getY();
				int x2 = vertices.get(i).getX();
				int y2 = vertices.get(i).getY();
				g.drawLine(x1, y1, x2, y2);
			}
		}
	}

	public Dimension getPreferredSize() {
		return new Dimension(1200, 800);
	}
}