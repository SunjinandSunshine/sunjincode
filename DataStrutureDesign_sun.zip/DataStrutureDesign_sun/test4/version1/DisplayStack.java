package version1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class DisplayStack extends JFrame {
	private static final long serialVersionUID = 1L;
	private MyArrayList<Integer> stack = new MyArrayList<Integer>();
	private DemoPanel view = new DemoPanel();
	private JPanel panel;
	private JButton jbtPush = new JButton("Push");
	private JButton jbtPop = new JButton("Pop");
	private JTextField jtfValue = new JTextField(3);
	private JLabel jlValue = new JLabel("Enter a value");

	public DisplayStack() {
		panel = new JPanel();

		panel.add(jlValue);
		panel.add(jtfValue);

		panel.add(jbtPush);
		panel.add(jbtPop);
		jbtPush.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stack.add(Integer.parseInt(jtfValue.getText()));
					view.repaint();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
		jbtPop.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stack.remove(stack.size - 1);
					JOptionPane.showMessageDialog(null, "ɾ���ɹ���", "���",
							JOptionPane.PLAIN_MESSAGE);
					view.repaint();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
		add(view);
		add(panel, BorderLayout.SOUTH);
	}

	public class DemoPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		private int startingX = 200;
		private int startingY = 500;
		private int boxWidth = 30;
		private int boxHeight = 20;

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			if (stack.size() == 0) {
				g.drawString("stack is empty", startingX, startingY);
			} else {

				int x = startingX + 10;
				int y = startingY + 10;

				for (int i = 0; i < stack.size(); i++) {
					g.drawRect(x, y, boxWidth, boxHeight);
					g.drawString(stack.get(i) + "", x + 10, y + 15);
					y = y - boxHeight;
				}
				g.drawString("top", x - 25, y + 15);
			}
		}
	}

	public static void main(String[] args) {
		DisplayStack frame = new DisplayStack();
		frame.setTitle("MyStack");
		frame.setSize(500, 700);
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
