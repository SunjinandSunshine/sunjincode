package version1;

import javax.swing.JApplet;

/**
 * 
 * @author SUNJIN
 *
 */

public class DisplayMyArrayList extends JApplet {
	private static final long serialVersionUID = 1L;

	public DisplayMyArrayList() {
		add(new ArrayListControl());
	}

	@Override
	public void init() {
		this.setSize(1000, 400);
	}
}
