package version1;

/**
 * 
 * @author SUNJIN
 *
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ArrayListControl extends JPanel {
	private static final long serialVersionUID = 1L;
	private String tips = null;
	private JTextField jtfValue = new JTextField(5);
	private JTextField jtfIndex = new JTextField(5);
	private JButton jbtSearch = new JButton("Search");
	private JButton jbtInsert = new JButton("Insert");
	private JButton jbtDelete = new JButton("Delete");
	private JButton jbtTrimToSize = new JButton("TrimToSize");
	private JLabel jlbTips = new JLabel();
	private MyArrayList<Integer> myArrayList = new MyArrayList<Integer>();
	private int changeColorIndex;

	public ArrayListControl() {
		setUI();
	}

	/** Initial UI for ArrayList Demo */
	private void setUI() {
		this.setLayout(new GridLayout(3, 1));
		tips = rebuildTips(myArrayList);
		jlbTips.setText(tips);
		JPanel tipsPanel = new JPanel();
		tipsPanel.add(jlbTips);

		JPanel operatePanel = new JPanel();
		operatePanel.add(new JLabel("Enter a value: "));
		operatePanel.add(jtfValue);
		operatePanel.add(new JLabel("Enter an index: "));
		operatePanel.add(jtfIndex);
		operatePanel.add(jbtSearch);
		operatePanel.add(jbtInsert);
		operatePanel.add(jbtDelete);
		operatePanel.add(jbtTrimToSize);

		add(tipsPanel);
		add(new DemoPanel());
		add(operatePanel);

		// Listener for the Insert button
		jbtSearch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try { // �����ǰ���value������Ԫ��
					int value = Integer.valueOf(jtfValue.getText());

					if (myArrayList.contains(value)) { // �ҵ������value
						changeColorIndex = myArrayList.indexOf(value);
						repaint();
						JOptionPane.showMessageDialog(null,
								"value " + value + " is in the index of "
										+ myArrayList.indexOf(value));
					} else {
						JOptionPane.showMessageDialog(null, "��list��û���ҵ�valueֵΪ"
								+ value + "��Ԫ�أ�");
					}
				} catch (Exception ex) {
				}

				try { // �����ǰ����±�������Ԫ��
					int index = Integer.valueOf(jtfIndex.getText());

					if (0 <= index && index < myArrayList.size - 1) {// �ҵ������value
						changeColorIndex = index;
						repaint();
						JOptionPane.showMessageDialog(null, "����IndexֵΪ" + index
								+ "����Ԫ����" + myArrayList.get(index));
					} else {
						JOptionPane.showMessageDialog(null, "�±�Խ�磡����������.");
					}
				} catch (Exception ex) {
				}
			}
		});
		jbtInsert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int value = Integer.valueOf(jtfValue.getText());
					int index = Integer.valueOf(jtfIndex.getText());

					if (index > myArrayList.size)
						index = myArrayList.size;

					myArrayList.add(index, value);
					changeColorIndex = index;
					jlbTips.setText(rebuildTips(myArrayList) + value + " "
							+ index);
					repaint();
				} catch (Exception ex) {
					try {
						int value = Integer.valueOf(jtfValue.getText());

						myArrayList.add(value);
						changeColorIndex = myArrayList.size - 1;
						jlbTips.setText(rebuildTips(myArrayList));
						repaint();
					} catch (Exception exx) {
						JOptionPane.showMessageDialog(null, "Wrong operation!");
					}
				}
			}
		});
		jbtDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try { // ɾ��ֵΪvalue��Ԫ��
					int value = Integer.valueOf(jtfValue.getText());

					if (myArrayList.contains(value)) {// �ҵ������value
						changeColorIndex = myArrayList.indexOf(value);
						repaint();

						if (JOptionPane.showConfirmDialog(null, "ȷ��ɾ����") == JOptionPane.YES_OPTION) {
							myArrayList.remove(myArrayList.indexOf(value));
							repaint();
							jlbTips.setText(rebuildTips(myArrayList));
						}
						changeColorIndex = -1;
					} else {
						JOptionPane.showMessageDialog(null, "��list��û���ҵ�valueֵΪ"
								+ value + "��Ԫ�أ�");
					}
				} catch (Exception ex) {
				}

				try { // ɾ���±�Ϊindex��Ԫ��
					int index = Integer.valueOf(jtfIndex.getText());

					if (0 <= index && index < myArrayList.size) {// �ҵ������value
						changeColorIndex = index;
						repaint();

						if (JOptionPane.showConfirmDialog(null, "ȷ��ɾ����") == JOptionPane.YES_OPTION) {
							myArrayList.remove(index);
							repaint();
							jlbTips.setText(rebuildTips(myArrayList));
							changeColorIndex = -1;
						}
					} else {
						JOptionPane.showMessageDialog(null, "�±�Խ�磡����������.");
					}
				} catch (Exception ex) {
				}
			}
		});
		jbtTrimToSize.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				myArrayList.trimToSize();
				jlbTips.setText(rebuildTips(myArrayList));
				repaint();
			}
		});
	}

	/** Rebuild tips string */
	public String rebuildTips(MyArrayList<Integer> list) {
		StringBuilder tips = new StringBuilder();

		if (list.size == 0)
			tips.append("array list is empty.   ");

		tips.append("size = " + list.size);
		tips.append(" and capacity is " + list.currentCapacity);

		return tips.toString();
	}

	class DemoPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		private int xcoordinate = 50;
		private int ycoordinate = 50;
		private int xGap = 50;
		private int yGap = 25;

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			for (int i = 0; i < myArrayList.size; i++) {
				if (i == changeColorIndex)
					displaySingleCellWithNumber(g, xcoordinate + xGap * i,
							ycoordinate, myArrayList.get(i), Color.red);
				else
					displaySingleCellWithNumber(g, xcoordinate + xGap * i,
							ycoordinate, myArrayList.get(i), Color.black);
			}

			for (int i = myArrayList.size; i < myArrayList.currentCapacity; i++) {
				displaySingleCellWithLine(g, xcoordinate + xGap * i,
						ycoordinate);
			}
		}

		/** Display a cell with number */
		private void displaySingleCellWithNumber(Graphics g, int x11, int y11,
				int number, Color colcor) {
			g.setColor(colcor);
			displayCellFrame(g, x11, y11);
			g.drawString(number + "", x11 + 17, y11 + 17);
		}

		/** Display a cell with line */
		private void displaySingleCellWithLine(Graphics g, int x11, int y11) {
			g.setColor(Color.BLACK);
			displayCellFrame(g, x11, y11);
			g.drawLine(x11, y11 + yGap, x11 + xGap, y11);
		}

		/** Display a cell frame */
		private void displayCellFrame(Graphics g, int x11, int y11) {
			int x12 = x11 + xGap;
			int y12 = y11;
			int x21 = x11;
			int y21 = y11 + yGap;
			int x22 = x11 + xGap;
			int y22 = y11 + yGap;

			g.drawLine(x11, y11, x21, y21);
			g.drawLine(x11, y11, x12, y12);
			g.drawLine(x12, y12, x22, y22);
			g.drawLine(x21, y21, x22, y22);
		}
	}
}
