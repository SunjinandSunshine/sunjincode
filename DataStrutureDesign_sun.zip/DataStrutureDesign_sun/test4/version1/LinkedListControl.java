package version1;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * 
 * @author SUNJIN
 *
 */
public class LinkedListControl extends JPanel {
	private static final long serialVersionUID = 1L;
	private LinkedList<Integer> myList = new LinkedList<Integer>();
	private DemoPanel demoPanel = new DemoPanel();
	// �������
	private JPanel panel;
	// ���尴ť
	private JButton jbtSearch = new JButton("Search");
	private JButton jbtInsert = new JButton("Insert");
	private JButton jbtDelete = new JButton("Delete");
	// ���������
	private JTextField jtfValue = new JTextField(5);
	private JTextField jtfIndex = new JTextField(5);
	// �����ǩ
	private JLabel jlValue = new JLabel("Enter a value ");
	private JLabel jlIndex = new JLabel("Enter an index");

	public LinkedListControl() {
		setUI();
	}

	/** Initial UI for LinkedList Demo */
	public void setUI() {
		this.setLayout(new GridLayout(2, 1));
		panel = new JPanel();
		panel.add(jlValue);
		panel.add(jtfValue);
		panel.add(jlIndex);
		panel.add(jtfIndex);
		panel.add(jbtSearch);
		panel.add(jbtInsert);
		panel.add(jbtDelete);
		add(demoPanel);
		add(panel);

		// Listener for the Insert button
		jbtSearch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (!myList.contains(Integer.parseInt(jtfValue.getText()))) {
						JOptionPane.showMessageDialog(null, "��Ԫ�ز��Ǵ�������", "����ʧ��", JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, jtfValue.getText() + "��������!", "���",
								JOptionPane.PLAIN_MESSAGE);
						demoPanel.repaint();
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
		jbtInsert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (jtfIndex.getText().trim().length() > 0)
						myList.add(Integer.parseInt(jtfIndex.getText()), Integer.parseInt(jtfValue.getText()));
					else
						myList.add(Integer.parseInt(jtfValue.getText()));
					demoPanel.repaint();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
		jbtDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (!myList.contains(Integer.parseInt(jtfValue.getText()))) {
						JOptionPane.showMessageDialog(null, "�����ֲ���������", "ɾ��ʧ��", JOptionPane.ERROR_MESSAGE);
					} else {
						myList.remove(new Integer(Integer.parseInt(jtfValue.getText())));
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���", "���", JOptionPane.PLAIN_MESSAGE);
						demoPanel.repaint();
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
	}

	public class DemoPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		private int startingX = 20;
		private int startingY = 20;
		private int boxWidth = 70;
		private int boxHeight = 25;
		private int arrowLineLength = 30;
		private int hGap = 80;

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			if (myList.size() == 0) {
				g.drawString("head =  null", startingX, startingY);
				g.drawString("tail = null", startingX, startingY + 15);
			} else {
				g.drawString("head", startingX, startingY);

				int x = startingX + 30;
				int y = startingY + 20;
				drawArrowLine(startingX + 5, startingY, x, y, g);
				g.setColor(Color.BLACK);

				for (int i = 0; i < myList.size(); i++) {
					g.drawRect(x, y, boxWidth, boxHeight);
					g.drawLine(x + arrowLineLength + 15, y, x + arrowLineLength + 15, y + boxHeight);
					g.setColor(Color.RED);

					if (i < myList.size() - 1)
						drawArrowLine(x + 40, y + boxHeight / 2, x + hGap, y + boxHeight / 2, g);
					g.setColor(Color.BLACK);
					g.drawString(myList.get(i) + "", x + 10, y + 15);
					x = x + hGap;
				}

				g.drawString("tail", x, startingY);
				drawArrowLine(x, startingY, x - hGap, y, g);
			}
		}

		public void drawArrowLine(int x1, int y1, int x2, int y2, Graphics g) {
			g.setColor(Color.black);
			g.drawLine(x1 + 13, y1, x2, y2);

			// find slope of this line
			double slope = ((((double) y1) - (double) y2)) / (((double) x1) - (((double) x2)));

			double arctan = Math.atan(slope);

			// This will flip the arrow 45 off of a
			// perpendicular line at pt x2
			double set45 = 1.57 / 2;

			// arrows should always point towards i, not i+1
			if (x1 < x2) {
				// add 90 degrees to arrow lines
				set45 = -1.57 * 1.5;
			}

			// set length of arrows
			int arrlen = 7;

			// draw arrows on line
			g.drawLine(x2, y2, (int) ((x2 + (Math.cos(arctan + set45) * arrlen))),
					(int) (((y2)) + (Math.sin(arctan + set45) * arrlen)));

			g.drawLine(x2, y2, (int) ((x2 + (Math.cos(arctan - set45) * arrlen))),
					(int) (((y2)) + (Math.sin(arctan - set45) * arrlen)));
		}
	}
}

