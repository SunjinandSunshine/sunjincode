package version1;

import javax.swing.JApplet;

public class DisplayMyLinkedList extends JApplet {
	
	private static final long serialVersionUID = 1L;

	public DisplayMyLinkedList() {
		add(new LinkedListControl());
	}

	@Override
	public void init() {
		this.setSize(1000, 400);
	}
}
