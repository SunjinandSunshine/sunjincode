package version1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * 
 * @author SUNJIN
 *
 */
public class DisplayQueue extends JFrame {
	private static final long serialVersionUID = 1L;
	private MyLinkedList<Integer> linkedList = new MyLinkedList<Integer>();
	private DemoPanel demoPanel = new DemoPanel();
	private JPanel panel;
	private JButton jbtEnqueue = new JButton("Enqueue");
	private JButton jbtDequeue = new JButton("Dequeue");
	private JTextField jtfValue = new JTextField(3);
	private JLabel jlValue = new JLabel("Enter a value");

	public DisplayQueue() {
		panel = new JPanel();

		panel.add(jlValue);
		panel.add(jtfValue);

		panel.add(jbtEnqueue);
		panel.add(jbtDequeue);
		jbtEnqueue.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					linkedList.addLast(Integer.parseInt(jtfValue.getText()));
					demoPanel.repaint();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});
		jbtDequeue.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					linkedList.removeFirst();
					JOptionPane.showMessageDialog(null, "ɾ���ɹ���", "���",
							JOptionPane.PLAIN_MESSAGE);
					demoPanel.repaint();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Wrong operation!");
				}
			}
		});

		add(demoPanel);
		add(panel, BorderLayout.SOUTH);
	}

	public class DemoPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		private int startingX = 20;
		private int startingY = 20;
		private int boxWidth = 40;
		private int boxHeight = 20;

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			if (linkedList.size() == 0) {
				g.drawString("queue is empty", startingX, startingY);
			} else {
				g.drawString("head", startingX, startingY);
				int x = startingX + 10;
				int y = startingY + 10;

				drawArrowLine(startingX, startingY, x + 20, y + 20, g);

				for (int i = 0; i < linkedList.size(); i++) {
					g.drawRect(x, y + 20, boxWidth, boxHeight);
					g.drawString(linkedList.get(i) + "", x + 10, y + 35);
					x = x + boxWidth;
				}

				g.drawString("tail", x, startingY);
				drawArrowLine(x, startingY, x - boxWidth / 2, y + 20, g);
			}
		}

		public void drawArrowLine(int x1, int y1, int x2, int y2, Graphics g) {
			g.setColor(Color.black);
			g.drawLine(x1 + 13, y1, x2, y2);

			// find slope of this line
			double slope = ((((double) y1) - (double) y2))
					/ (((double) x1) - (((double) x2)));

			double arctan = Math.atan(slope);

			// This will flip the arrow 45 off of a
			// perpendicular line at pt x2
			double set45 = 1.57 / 2;

			// arrows should always point towards i, not i+1
			if (x1 < x2) {
				// add 90 degrees to arrow lines
				set45 = -1.57 * 1.5;
			}

			// set length of arrows
			int arrlen = 7;

			// draw arrows on line
			g.drawLine(x2, y2,
					(int) ((x2 + (Math.cos(arctan + set45) * arrlen))),
					(int) (((y2)) + (Math.sin(arctan + set45) * arrlen)));

			g.drawLine(x2, y2,
					(int) ((x2 + (Math.cos(arctan - set45) * arrlen))),
					(int) (((y2)) + (Math.sin(arctan - set45) * arrlen)));
		}
	}

	public static void main(String[] args) {
		DisplayQueue frame = new DisplayQueue();
		frame.setTitle("MyQueue");
		frame.setSize(1000, 320);
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
