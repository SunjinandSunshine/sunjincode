package version2;

import javax.swing.JApplet;

/**
 * 
 * @author SUNJIN
 *
 */
@SuppressWarnings("serial")
public class DisplayBinaryTree extends JApplet {

	public DisplayBinaryTree() {
		add(new TreeControl(new BinaryTree<Integer>()));
	}
}
