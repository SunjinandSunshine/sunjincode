package version2;

/**
 * 
 * @author SUNJIN
 *
 */
public interface Tree<E extends Comparable<E>> {

	public boolean search(E e);// �ж��Ƿ���ڸ�Ԫ�أ�

	public boolean insert(E e);// ����Ԫ��

	public boolean delete(E e);// ɾ��Ԫ�أ�

	public void inorder();

	public void postorder();

	public void preorder();

	public int getSize();

	public boolean isEmpty();

	@SuppressWarnings("rawtypes")
	public java.util.Iterator iterator();

}
