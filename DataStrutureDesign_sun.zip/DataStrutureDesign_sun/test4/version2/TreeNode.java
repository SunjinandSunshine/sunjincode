package version2;

/**
 * 
 * @author SUNJIN
 *
 */
public class TreeNode<E> {
	E element;
	TreeNode<E> left;
	TreeNode<E> right;

	public TreeNode(E e) {
		element = e;
	}
}
