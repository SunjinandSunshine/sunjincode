package version3;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * 
 * @author SUNJIN m�����εĿ����� n�����εĸߣ��� �Զ�����ι��
 *
 */
public class TailsModelGUI extends Application {

	int m = 3;
	int n = 3;

	public void start(Stage stage) throws Exception {

		MyModel tailsModel = new MyModel(m, n);
		tailsModel.initial(stage);
		stage.setTitle("tailsModel@SunjinCopyRight");
		stage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
