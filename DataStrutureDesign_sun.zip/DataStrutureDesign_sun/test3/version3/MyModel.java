package version3;

/**
 * 
 * @author SUNJIN
 *
 */
/*
 * �Զ���Ӳ�ҵķ�ת��ʽ��ֻ��ת��Ӳ�ҵ��Ϸ� �� �·���
 */
import java.util.ArrayList;
import java.util.List;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * 
 * @author SUNJIN
 *
 */
public class MyModel {

	public static int width;
	public static int height;
	public static int NUMBER_OF_NODES;
	protected AbstractGraph<Integer>.Tree tree; // Define a tree
	private Rectangle[] rectangle;
	private Label[][] label;
	private Label[] lb;
	private Label[] newlb;
	private int solution;
	private List<Integer> path;
	private int index;
	private char[] nodes;

	/** Construct a model */
	public MyModel(int height, int width) {

		MyModel.height = height;
		MyModel.width = width;
		MyModel.NUMBER_OF_NODES = (int) Math.pow(2, height * width);
		// Create edges
		List<AbstractGraph.Edge> edges = getEdges();

		// Create a graph
		UnweightedGraph<Integer> graph = new UnweightedGraph<Integer>(edges,
				NUMBER_OF_NODES);

		// Obtain a BSF tree rooted at the target node
		tree = graph.bfs(NUMBER_OF_NODES - 1);
	}

	/** Create all edges for the graph */
	private List<AbstractGraph.Edge> getEdges() {
		List<AbstractGraph.Edge> edges = new ArrayList<AbstractGraph.Edge>(); // Store
																				// edges

		for (int u = 0; u < NUMBER_OF_NODES; u++) {
			for (int k = 0; k < width * height; k++) {
				char[] node = getNode(u); // Get the node for vertex u
				if (node[k] == 'H') {
					int v = getFlippedNode(node, k);
					// Add edge (v, u) for a legal move from node u to node v
					edges.add(new AbstractGraph.Edge(v, u));
				}
			}
		}
		return edges;
	}

	public void initial(Stage stage) {

		lb = new Label[height * width];
		int m = height;
		int n = width;
		Pane pane = new Pane();

		Rectangle retangle = new Rectangle(138, 144);
		retangle.setStroke(Color.BLACK);
		retangle.setFill(Color.WHITE);
		retangle.setLayoutX(30);
		retangle.setLayoutY(100);
		newlb = new Label[height * width];

		Rectangle newretangle = new Rectangle(138, 144);
		newretangle.setStroke(Color.BLACK);
		newretangle.setFill(Color.WHITE);
		newretangle.setLayoutX(30);
		newretangle.setLayoutY(100);

		pane.getChildren().add(retangle);

		index = 1 + (int) (Math.random() * (int) Math.pow(2, m * n));

		nodes = getNode(index);

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				lb[m * i + j] = new Label(nodes[m * i + j] + "");
				lb[m * i + j].setLayoutX(45 + 50 * j);
				lb[m * i + j].setLayoutY(120 + 50 * i);
				lb[m * i + j].setFont(new Font(20));
				pane.getChildren().add(lb[m * i + j]);
			}
		}

		Button solve = new Button("solve");
		solve.setLayoutX(600);
		solve.setLayoutY(500);
		solve.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		solve.setFont(new Font("Arial", 18));

		solve.setOnAction(e -> {
			path = getShortestPath(getIndex(nodes));

			if (path.size() == 1) {

				Alert information = new Alert(Alert.AlertType.INFORMATION,
						"�޽⣡��");
				information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
				information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
				information.show();
			} else {

				rectangle = new Rectangle[path.size()];

				solution = path.size();

				label = new Label[solution][m * n];
				char[] temp = getNode(path.get(0));

				for (int i = 1; i < path.size(); i++) {

					rectangle[i] = new Rectangle(138, 144);
					rectangle[i].setStroke(Color.BLACK);
					rectangle[i].setFill(Color.WHITE);
					rectangle[i].setLayoutX(178 + (i - 1) * 148);
					rectangle[i].setLayoutY(100);
					pane.getChildren().add(rectangle[i]);

					char[] newnodes = getNode(path.get(i).intValue());

					for (int j = 0; j < m * n; j++) {

						label[i][j] = new Label(newnodes[j] + "");

						label[i][j]
								.setLayoutX(193 + j % m * 50 + (i - 1) * 148);
						label[i][j].setTextFill(Color.BLACK);
						label[i][j].setLayoutY(120 + j / n * 50);
						label[i][j].setFont(new Font(20));
						if (temp[j] != newnodes[j]) {
							label[i][j].setTextFill(Color.RED);
						}
						pane.getChildren().add(label[i][j]);
					}
					temp = newnodes;
				}
			}

		});

		Button start_over = new Button("start_over");
		start_over.setLayoutX(700);
		start_over.setLayoutY(500);
		start_over
				.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		start_over.setFont(new Font("Arial", 18));
		start_over.setOnAction(e -> {

			pane.getChildren().remove(retangle);
			pane.getChildren().remove(newretangle);

			for (int i = 1; i < solution; i++) {

				pane.getChildren().remove(rectangle[i]);

			}

			for (int i = 0; i < m * n; i++) {
				pane.getChildren().remove(lb[i]);
				pane.getChildren().remove(newlb[i]);

			}

			for (int i = 0; i < path.size() - 1; i++) {
				for (int j = 0; j < m * n; j++) {
					pane.getChildren().remove(label[i + 1][j]);
				}
			}

			index = 1 + (int) (Math.random() * (int) Math.pow(2, m * n));

			retangle.setStroke(Color.BLACK);
			retangle.setFill(Color.WHITE);

			retangle.setLayoutX(30);
			retangle.setLayoutY(100);

			pane.getChildren().add(newretangle);
			index = 1 + (int) (Math.random() * (int) Math.pow(2, m * n));
			nodes = getNode(index);

			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					newlb[m * i + j] = new Label(nodes[m * i + j] + "");
					newlb[m * i + j].setLayoutX(45 + 50 * j);
					newlb[m * i + j].setLayoutY(120 + 50 * i);
					newlb[m * i + j].setFont(new Font(20));
					pane.getChildren().add(newlb[m * i + j]);
				}
			}
		});

		pane.getChildren().add(solve);
		pane.getChildren().add(start_over);
		Scene scene = new Scene(pane, 1400, 700);

		scene.getStylesheets().add(
				MyModel.class.getResource("image/back.css").toExternalForm());

		stage.setScene(scene);
	}

	public static int getFlippedNode(char[] node, int position) {

		int row = position / width;
		int column = position % width;

		flipACell(node, row, column);
		flipACell(node, row - 1, column);// ��
		flipACell(node, row + 1, column);// ��
		// flipACell(node, row, column - 1);// ��
		// flipACell(node, row, column + 1);// ��

		// flipACell(node, row - 1, column - 1);// ����
		// flipACell(node, row + 1, column - 1);// ����
		// flipACell(node, row + 1, column + 1);// ����
		// flipACell(node, row - 1, column + 1);// ����

		return getIndex(node);
	}

	public static void flipACell(char[] node, int row, int column) {
		if (row >= 0 && row <= height - 1 && column >= 0 && column <= width - 1) {
			// Within the boundary
			if (node[row * width + column] == 'H')
				node[row * width + column] = 'T'; // Flip from H to T
			else
				node[row * width + column] = 'H'; // Flip from T to H
		}
	}

	public static int getIndex(char[] node) {
		int result = 0;
		for (int i = 0; i < width * height; i++)
			if (node[i] == 'T')
				result = result * 2 + 1;
			else
				result = result * 2 + 0;
		return result;
	}

	public static char[] getNode(int index) {
		char[] result = new char[width * height];

		for (int i = 0; i < width * height; i++) {
			int digit = index % 2;
			if (digit == 0)
				result[width * height - 1 - i] = 'H';
			else
				result[width * height - 1 - i] = 'T';
			index = index / 2;
		}
		return result;
	}

	public List<Integer> getShortestPath(int nodeIndex) {
		return tree.getPath(nodeIndex);
	}
}