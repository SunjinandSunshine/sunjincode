package version1;

import java.util.List;

/**
 * 
 * @author SUNJIN
 *
 * @param <V>
 */

public class UnweightedGraph<V> extends AbstractGraph<V> {

	/** ͨ��һ��edges�Ͱ���һ����������鹹����ͼ **/
	public UnweightedGraph(int[][] edges, V[] vertices) {
		super(edges, vertices);
	}

	public UnweightedGraph(List<Edge> edges, List<V> vertices) {
		super(edges, vertices);
	}

	public UnweightedGraph(List<Edge> edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}

	public UnweightedGraph(int[][] edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}
}
