package problem1;
/**
 * 
 * @author SUNJIN
 *
 */


//A linked structure for tree
	public class Tree implements Comparable<Tree> {
		Node root;

		// Create a new node as the parent of t1 and t2
		public Tree(Tree t1, Tree t2) {
			root = new Node();
			root.left = t1.root;
			root.right = t2.root;
			root.weight = t1.root.weight + t2.root.weight;
		}

		// Create a tree with a single node
		public Tree(int weight, char element) {
			root = new Node(weight, element);
		}

		public int compareTo(Tree o) {
			// Purposely reverse the order so the smallest one will be removed
			// first from the heap
			if (root.weight < o.root.weight)
				return 1;
			else if (root.weight == o.root.weight)
				return 0;
			else
				return -1;
		}

		public class Node {
			char element; // For a leaf node, element stores the character in
							// the text
			int weight; // weight is stored in the node
			Node left;
			Node right;
			String code = "";

			public Node() {
			}

			public Node(int weight, char element) {
				this.weight = weight;
				this.element = element;
			}
		}
	}
