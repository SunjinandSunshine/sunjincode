package problem1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javafx.application.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * 
 * @author SUNJIN
 *
 */

public class Index extends Application {

	private String huffcodes[];// ����������
	private static Tree tree;// ��������

	@Override
	public void start(Stage primaryStage) {

		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		Label label = new Label("���ݵ�ѹ�����ѹ");
		label.setTextFill(Color.web("#0076a3"));
		label.setFont(new Font("Arial", 28));
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(35);
		pane.setVgap(35);

		Label lb1 = new Label("1.��ʼ�������ļ�");
		lb1.setFont(new Font("Arial", 17));

		Button bt1 = new Button("����");
		bt1.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		bt1.setFont(new Font("Arial", 18));
		bt1.setTextFill(Color.web("#0076a3"));

		Label lb2 = new Label("2.���ļ�����");
		lb2.setFont(new Font("Arial", 17));
		Button bt2 = new Button("����");
		bt2.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		bt2.setFont(new Font("Arial", 18));
		bt2.setTextFill(Color.web("#0076a3"));

		Label lb3 = new Label("3.���ļ�����");
		lb3.setFont(new Font("Arial", 17));
		Button bt3 = new Button("����");
		bt3.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		bt3.setFont(new Font("Arial", 18));
		bt3.setTextFill(Color.web("#0076a3"));

		Label lb4 = new Label("4.��ӡ�����ļ�");
		lb4.setFont(new Font("Arial", 17));
		Button bt4 = new Button("����");
		bt4.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		bt4.setFont(new Font("Arial", 18));
		bt4.setTextFill(Color.web("#0076a3"));

		Label lb5 = new Label("5.��ӡ��������");
		lb5.setFont(new Font("Arial", 17));
		Button bt5 = new Button("����");
		bt5.setStyle("-fx-border-color:green;-fx-background-color:lightgreen");
		bt5.setFont(new Font("Arial", 18));
		bt5.setTextFill(Color.web("#0076a3"));

		pane.add(label, 0, 0);

		pane.add(lb1, 0, 1);
		pane.add(bt1, 1, 1);

		pane.add(lb2, 0, 2);
		pane.add(bt2, 1, 2);

		pane.add(lb3, 0, 3);
		pane.add(bt3, 1, 3);

		pane.add(lb4, 0, 4);
		pane.add(bt4, 1, 4);

		pane.add(lb5, 0, 5);
		pane.add(bt5, 1, 5);

		// ����ť�����¼�������
		bt1.setOnAction(e -> initialEvent(primaryStage));
		bt2.setOnAction(e -> codingFile(primaryStage));
		bt3.setOnAction(e -> decodingFile(primaryStage));
		bt4.setOnAction(e -> printFile(primaryStage));
		bt5.setOnAction(e -> printTree(primaryStage));

		Scene scene = new Scene(pane, 1400, 700);
		scene.getStylesheets().add(
				Index.class.getResource("image/huffman.css").toExternalForm());

		primaryStage.setTitle("����������@Sunjincopyright");
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public void initialEvent(Stage stage) {

		// �ر����˵���
		stage.hide();

		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(100, 10, 10, 80));
		pane.setVgap(200);
		pane.setHgap(-50);
		Label label = new Label("�������ַ�����");
		label.setFont(new Font("Arial", 20));
		TextField text = new TextField();
		HBox hb = new HBox();
		Button bt1 = new Button("����");
		Button bt2 = new Button("����");
		bt2.setOnAction(e -> {
			start(stage);
		});
		bt1.setOnAction(e -> {

			String textf = text.getText();
			if (textf == null) {
				Alert information = new Alert(Alert.AlertType.INFORMATION,
						"���벻��Ϊ�գ�");
				information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
				information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information

			} else {

				int[] counts = getCharacterFrequency(textf);
				tree = getHuffmanTree(counts);
				huffcodes = getCode(tree.root);

				try {
					DataOutputStream fileOutput1 = new DataOutputStream(
							new BufferedOutputStream(new FileOutputStream(
									"C:\\test\\hfmtree.dat")));

					DataOutputStream fileOutput2 = new DataOutputStream(
							new BufferedOutputStream(new FileOutputStream(
									"C:\\test\\tobetrains.txt")));
					for (int j = 0; j < textf.length(); j++) {
						fileOutput2.write(textf.charAt(j));
					}

					for (int i = 0; i <= 255; i++) {
						if (huffcodes[i] != null) {
							fileOutput1.writeUTF(huffcodes[i]);
						}
					}
					fileOutput1.close();
					fileOutput2.close();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch��
					e1.printStackTrace();
				}

				Alert information = new Alert(Alert.AlertType.INFORMATION,
						"����ɹ���");
				information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
				information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
				information.show();
				Button infor = new Button("show Information");
				infor.setOnAction((ActionEvent) -> {
					information.showAndWait(); // ��ʾ������ͬʱ��������ȹ���
				});
			}
		});

		bt1.setFont(new Font("Arial", 20));
		bt1.setTextFill(Color.web("#0076a3"));
		bt1.setStyle("-fx-background-color:lightgreen");
		bt2.setFont(new Font("Arial", 20));
		bt2.setStyle("-fx-background-color:lightgray");
		hb.getChildren().addAll(label, text);
		pane.add(hb, 0, 0);
		pane.add(bt1, 0, 1);
		pane.add(bt2, 1, 1);
		hb.setSpacing(30);
		Scene scene = new Scene(pane, 1400, 700);
		scene.getStylesheets().add(
				Index.class.getResource("image/huffman2.css").toExternalForm());
		stage.setTitle("��ʼ���˵�");
		stage.setScene(scene);
		stage.show();

	}

	public static int[] getCharacterFrequency(String text) {
		int[] counts = new int[256];
		for (int i = 0; i < text.length(); i++) {
			counts[(int) text.charAt(i)]++;
		}
		return counts;
	}

	// get a tree
	public static Tree getHuffmanTree(int[] counts) {
		Heap<Tree> heap = new Heap<Tree>();

		for (int i = 0; i < counts.length; i++) {
			if (counts[i] > 0)
				heap.add(new Tree(counts[i], (char) i));
		}

		while (heap.getSize() > 1) {
			Tree t1 = heap.remove();
			Tree t2 = heap.remove();
			heap.add(new Tree(t1, t2));
		}

		return heap.remove(); // ���յĹ���������
	}

	public static String[] getCode(Tree.Node root) {

		if (root == null)
			return null;
		String[] codes = new String[256];
		assignCode(root, codes);
		return codes;
	}

	// This method is called once after a Huffman tree is built
	public static void assignCode(Tree.Node root, String[] codes) {

		if (root.left != null) {
			root.left.code = root.code + "0";
			assignCode(root.left, codes);

			root.right.code = root.code + "1";
			assignCode(root.right, codes);
		} else {
			codes[(int) root.element] = root.code;
		}
	}

	@SuppressWarnings({})
	// ���ļ�����
	public void codingFile(Stage stage) {

		stage.hide();
		GridPane pane = new GridPane();
		pane.setHgap(150);
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(12, 12, 12, 12));

		Button bt1 = new Button("����");
		bt1.setFont(new Font("Arial", 20));
		bt1.setTextFill(Color.web("#0076a3"));
		bt1.setStyle("-fx-background-color:lightgreen");
		bt1.setOnAction(e -> {

			BufferedInputStream fileInput = null;

			try {
				fileInput = new BufferedInputStream(new FileInputStream(
						"C:\\test\\tobetrains.txt"));
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}

			DataOutputStream fileOutput = null;
			try {
				fileOutput = new DataOutputStream(new BufferedOutputStream(
						new FileOutputStream("C:\\test\\huffcode.txt")));
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			int r;
			try {
				while ((r = fileInput.read()) != -1) {
					fileOutput.writeChars(huffcodes[r]);
				}
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			try {
				fileInput.close();
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			try {
				fileOutput.close();
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			try {
				DataInputStream fileInput2 = new DataInputStream(
						new FileInputStream("C:\\test\\huffcode.txt"));
				DataOutputStream fileOutput2 = new DataOutputStream(
						new BufferedOutputStream(new FileOutputStream(
								"C:\\test\\codefile.txt")));
				char r1;
				int count = 0;

				StringBuffer value = new StringBuffer();
				try {
					try {
						while ((r1 = fileInput2.readChar()) != -1) {

							count++;
							value.append(r1);
							if (count == 31) {
								fileOutput2.writeInt(Integer.parseInt(
										new String(value), 2));

								// ��ʼ��count,value;
								count = 0;
								value = new StringBuffer();
							}
						}

					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				} finally {

					try {

						fileOutput2.writeInt(Integer.parseInt(
								new String(value), 2));
						fileInput2.close();

					} catch (Exception e2) {
						// TODO �Զ����ɵ� catch ��
						e2.printStackTrace();
					}
					try {
						fileOutput2.close();
					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				}

			} catch (FileNotFoundException e11) {

			}

			Alert information = new Alert(Alert.AlertType.INFORMATION,
					"�ļ�ѹ���ɹ���");
			information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
			information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
			information.show();
		});

		Button bt2 = new Button("����");
		bt2.setOnAction(e -> {
			start(stage);
		});
		bt2.setFont(new Font("Arial", 20));
		bt2.setTextFill(Color.web("#0076a3"));
		bt2.setStyle("-fx-background-color:lightgray");

		pane.add(bt1, 0, 0);
		pane.add(bt2, 1, 0);

		Scene scene = new Scene(pane, 1400, 700);
		scene.getStylesheets().add(
				Index.class.getResource("image/huffman2.css").toExternalForm());
		stage.setTitle("����");
		stage.setScene(scene);
		stage.show();

	}

	// ���ļ�����
	public void decodingFile(Stage stage) {

		stage.hide();

		GridPane pane = new GridPane();
		pane.setHgap(150);
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(12, 12, 12, 12));

		Button bt1 = new Button("����");
		bt1.setFont(new Font("Arial", 20));
		bt1.setTextFill(Color.web("#0076a3"));
		bt1.setStyle("-fx-background-color:lightgreen");
		bt1.setOnAction(e -> {

			DataInputStream in = null;
			try {
				in = new DataInputStream(new FileInputStream(
						"C:\\test\\huffcode.txt"));
			} catch (Exception e3) {
				// TODO �Զ����ɵ� catch ��
				e3.printStackTrace();
			}
			DataOutputStream out = null;
			try {
				out = new DataOutputStream(new FileOutputStream(
						("C:\\test\\textfile.txt")));
			} catch (Exception e3) {
				// TODO �Զ����ɵ� catch ��
				e3.printStackTrace();
			}
			StringBuffer s = new StringBuffer();
			char q;
			try {
				while ((q = in.readChar()) != -1) {
					s.append(q);
					for (int j = 0; j < 255; j++) {

						if (huffcodes[j] != null
								&& new String(s).compareTo(huffcodes[j]) == 0) {
							out.write((char) j);
							s = new StringBuffer();
						}
					}
				}
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��

				e1.printStackTrace();
			}
			try {
				in.close();
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}

			Alert information = new Alert(Alert.AlertType.INFORMATION,
					"�ļ���ѹ�ɹ���");
			information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
			information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
			information.show();

		});

		Button bt2 = new Button("����");
		bt2.setOnAction(e -> {
			start(stage);
		});
		bt2.setFont(new Font("Arial", 20));
		bt2.setTextFill(Color.web("#0076a3"));
		bt2.setStyle("-fx-background-color:lightgray");

		pane.add(bt1, 0, 0);
		pane.add(bt2, 1, 0);

		Scene scene = new Scene(pane, 1400, 700);
		scene.getStylesheets().add(
				Index.class.getResource("image/huffman2.css").toExternalForm());
		stage.setTitle("����");
		stage.setScene(scene);
		stage.show();

	}

	@SuppressWarnings("resource")
	public void printFile(Stage stage) {
		stage.hide();
		GridPane pane = new GridPane();
		TextArea textarea = new TextArea();

		pane.setAlignment(Pos.CENTER);
		pane.setHgap(-55);
		pane.setVgap(50);
		Button bt1 = new Button("��ӡ�����ļ�");
		bt1.setFont(new Font("Arial", 20));
		bt1.setTextFill(Color.web("#0076a3"));
		bt1.setStyle("-fx-background-color:lightgreen");
		bt1.setOnAction(e -> {
			String s = "";
			int count = 0;
			try {
				DataInputStream fileInput = new DataInputStream(
						new FileInputStream("C:\\test\\huffcode.txt"));

				int r;
				while ((r = fileInput.readChar()) != -1) {
					s += r - '0' + " ";
					count++;

					if (count == 50) {
						s += "\n";
					}
				}
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				textarea.setText(s);
				e1.printStackTrace();

			}
			Alert information = new Alert(Alert.AlertType.INFORMATION,
					"��Ӧ�������£�");
			information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
			information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
			information.show();
		});
		Button bt2 = new Button("����");
		bt2.setFont(new Font("Arial", 20));
		bt2.setTextFill(Color.web("#0076a3"));
		bt2.setStyle("-fx-background-color:lightgray");
		bt2.setOnAction(e -> {
			start(stage);
		});
		pane.add(bt1, 0, 0);
		pane.add(bt2, 1, 0);
		pane.add(textarea, 0, 1);
		Scene scene = new Scene(pane, 1400, 700);
		scene.getStylesheets().add(
				Index.class.getResource("image/huffman3.css").toExternalForm());
		stage.setTitle("��ӡ�����ļ�");
		stage.setScene(scene);
		stage.show();

	}

	public void printTree(Stage stage) {

		stage.hide();

		Group root = new Group();
		GridPane pane = new GridPane();
		pane.setHgap(100);
		pane.setAlignment(Pos.BOTTOM_CENTER);
		pane.setPadding(new Insets(12, 12, 12, 12));
		Button bt2 = new Button("����");
		Button lb = new Button("��ѯ�ַ�����");
		TextField text = new TextField();
		bt2.setOnAction(e -> {
			start(stage);
		});
		bt2.setFont(new Font("Arial", 20));
		lb.setFont(new Font("Arial", 16));
		lb.setTextFill(Color.web("#0076a3"));
		lb.setStyle("-fx-background-color:lightgray");
		bt2.setTextFill(Color.web("#0076a3"));
		bt2.setStyle("-fx-background-color:lightgray");

		Canvas canvas = new Canvas(1400, 700);
		GraphicsContext g = canvas.getGraphicsContext2D();

		drawShapes(g);
		pane.add(bt2, 0, 0);
		pane.add(lb, 1, 0);
		pane.add(text, 2, 0);
		root.getChildren().add(canvas);
		root.getChildren().add(pane);

		lb.setOnAction(e -> {

			// �ж�����Ϊ��
			if (text.getText() == null) {
				Alert information = new Alert(Alert.AlertType.INFORMATION,
						"û�пɲ�ѯ����Ϣ��");
				information.setTitle("information");
				// ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
				information.setHeaderText("Information"); //
				// ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
				information.show();
			}

			for (int i = 0; i < huffcodes.length; i++) {
				if (text.getText().charAt(0) == (char) i) {
					Alert information = new Alert(Alert.AlertType.INFORMATION,
							huffcodes[i]);
					information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
					information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
					information.show();
					break;
				}
			}

		});

		stage.setScene(new Scene(root));
		stage.show();

	}

	private void drawShapes(GraphicsContext gc) {
		if (tree.root != null) {
			displayTree(gc, tree.root, 600, 100, 200);
		}
	}

	private void displayTree(GraphicsContext g, Tree.Node root, int x, int y,
			int hGap) {

		int radius = 20;
		int vGap = 50;
       
		g.fillOval(x - radius, y - radius, 2 * radius, 2 * radius);
		g.setFill(Color.YELLOWGREEN);
		g.strokeText(root.element + "", x - 5, y + 4);

		if (root.left != null) {
			connectLeftChild(g, x - hGap, y + vGap, x, y);
			displayTree(g, root.left, x - hGap, y + vGap, hGap / 2);
		}
		if (root.right != null) {
			connectRightChild(g, x + hGap, y + vGap, x, y);
			displayTree(g, root.right, x + hGap, y + vGap, hGap / 2);
		}
	}

	private void connectLeftChild(GraphicsContext g, int x1, int y1, int x2,
			int y2) {
		int radius = 20;
		int vGap = 50;
		double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
		int x11 = (int) (x1 + radius * (x2 - x1) / d);
		int y11 = (int) (y1 - radius * vGap / d);
		int x21 = (int) (x2 - radius * (x2 - x1) / d);
		int y21 = (int) (y2 + radius * vGap / d);
		g.strokeLine(x11, y11, x21, y21);
		g.strokeText("0", (x11 + x21) / 2, (y11 + y21) / 2);
	}

	private void connectRightChild(GraphicsContext g, int x1, int y1, int x2,
			int y2) {
		int radius = 20;
		int vGap = 50;
		double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
		int x11 = (int) (x1 - radius * (x1 - x2) / d);
		int y11 = (int) (y1 - radius * vGap / d);
		int x21 = (int) (x2 + radius * (x1 - x2) / d);
		int y21 = (int) (y2 + radius * vGap / d);
		g.strokeLine(x11, y11, x21, y21);
		g.strokeText("1", (x11 + x21) / 2, (y11 + y21) / 2);
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
