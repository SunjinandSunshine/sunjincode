package problem1;

/**
 * 
 * @author SUNJIN
 *
 */

@SuppressWarnings("rawtypes")
public class Heap<E extends Comparable> {
	// Heap �ĵײ�ʵ���� ���顣
	private java.util.ArrayList<E> list = new java.util.ArrayList<E>();

	public Heap() {

	}

	public Heap(E[] objects) {
		for (int i = 0; i < objects.length; i++)
			add(objects[i]);
	}

	@SuppressWarnings("unchecked")
	public void add(E newObjects) {
		list.add(newObjects);

		int currentIndex = list.size() - 1;

		while (currentIndex > 0) {

			int parentIndex = (currentIndex - 1) / 2;

			if (list.get(parentIndex).compareTo(list.get(currentIndex)) < 0) {

				E temp = list.get(currentIndex);
				list.set(currentIndex, list.get(parentIndex));
				list.set(parentIndex, temp);

			} else
				break;// ���ݴ�С˳���Ѿ��źã�

			currentIndex = parentIndex;
		}
	}

	@SuppressWarnings("unchecked")
	// ɾ����С�Ľڵ㣻
	public E remove() {

		if (list.size() == 0)
			return null;

		E removeObject = list.get(0);

		list.set(0, list.get(list.size() - 1));

		list.remove(list.size() - 1);

		int currentIndex = 0;

		while (currentIndex < list.size()) {

			int leftChildIndex = 2 * currentIndex + 1;

			int rightChildIndex = 2 * currentIndex + 2;

			if (leftChildIndex >= list.size())
				break; // a element is a tree;

			int maxIndex = leftChildIndex;

			if (rightChildIndex < list.size()) {

				if (list.get(maxIndex).compareTo(list.get(rightChildIndex)) < 0) {
					maxIndex = rightChildIndex;
				}
			}
			if (list.get(maxIndex).compareTo(list.get(currentIndex)) > 0) {

				E temp = list.get(maxIndex);
				list.set(maxIndex, list.get(currentIndex));
				list.set(currentIndex, temp);
				currentIndex = maxIndex;

			} else
				break;
		}

		return removeObject;
	}

	public int getSize() {

		return list.size();

	}

	@Override
	public String toString() {

		StringBuilder result = new StringBuilder("heap:[");

		for (int i = 0; i < list.size() - 1; i++) {

			result.append(list.get(i));
			result.append(", ");
		}

		result.append(list.get(list.size() - 1));

		return result.toString() + "]";
	}
}
