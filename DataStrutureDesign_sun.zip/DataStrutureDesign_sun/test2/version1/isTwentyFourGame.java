package version1;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * 
 * @author SUNJIN
 *
 */
public class isTwentyFourGame extends Application {

	// ��ʼ�� 52 �� ͼƬ��
	private Image n1 = new Image("images/1.png");
	private Image n2 = new Image("images/2.png");
	private Image n3 = new Image("images/3.png");
	private Image n4 = new Image("images/4.png");
	private Image n5 = new Image("images/5.png");
	private Image n6 = new Image("images/6.png");
	private Image n7 = new Image("images/7.png");
	private Image n8 = new Image("images/8.png");
	private Image n9 = new Image("images/9.png");
	private Image n10 = new Image("images/10.png");
	private Image n11 = new Image("images/11.png");
	private Image n12 = new Image("images/12.png");
	private Image n13 = new Image("images/13.png");

	private Image n14 = new Image("images/14.png");
	private Image n15 = new Image("images/15.png");
	private Image n16 = new Image("images/16.png");
	private Image n17 = new Image("images/17.png");
	private Image n18 = new Image("images/18.png");
	private Image n19 = new Image("images/19.png");
	private Image n20 = new Image("images/20.png");
	private Image n21 = new Image("images/21.png");
	private Image n22 = new Image("images/22.png");
	private Image n23 = new Image("images/23.png");
	private Image n24 = new Image("images/24.png");
	private Image n25 = new Image("images/25.png");
	private Image n26 = new Image("images/26.png");

	private Image n27 = new Image("images/27.png");
	private Image n28 = new Image("images/28.png");
	private Image n29 = new Image("images/29.png");
	private Image n30 = new Image("images/30.png");
	private Image n31 = new Image("images/31.png");
	private Image n32 = new Image("images/32.png");
	private Image n33 = new Image("images/33.png");
	private Image n34 = new Image("images/34.png");
	private Image n35 = new Image("images/35.png");
	private Image n36 = new Image("images/36.png");
	private Image n37 = new Image("images/37.png");
	private Image n38 = new Image("images/38.png");
	private Image n39 = new Image("images/39.png");

	private Image n40 = new Image("images/40.png");
	private Image n41 = new Image("images/41.png");
	private Image n42 = new Image("images/42.png");
	private Image n43 = new Image("images/43.png");
	private Image n44 = new Image("images/44.png");
	private Image n45 = new Image("images/45.png");
	private Image n46 = new Image("images/46.png");
	private Image n47 = new Image("images/47.png");
	private Image n48 = new Image("images/48.png");
	private Image n49 = new Image("images/49.png");
	private Image n50 = new Image("images/50.png");
	private Image n51 = new Image("images/51.png");
	private Image n52 = new Image("images/52.png");

	// ��ȡ�Ŀ��Ƶ����֣�
	private int card1;
	private int card2;
	private int card3;
	private int card4;

	private Label label;
	private TextField text;
	private Button verify;
	private ImageView v1;
	private ImageView v2;
	private ImageView v3;
	private ImageView v4;

	private Image[] us = { n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12,
			n13, n14, n15, n16, n17, n18, n19, n20, n21, n22, n23, n24, n25,
			n26, n27, n28, n29, n30, n31, n32, n33, n34, n35, n36, n37, n38,
			n39, n40, n41, n42, n43, n44, n45, n46, n47, n48, n49, n50, n51,
			n52 };

	@SuppressWarnings("static-access")
	@Override
	public void start(Stage stage) throws Exception {

		// ������ɵ����֣�
		card1 = (int) (Math.random() * (51));
		card2 = (int) (Math.random() * (51));
		card3 = (int) (Math.random() * (51));
		card4 = (int) (Math.random() * (51));

		GridPane pane = new GridPane();
		Button refesh = new Button("Refesh");

		// �л������ƣ�
		refesh.setOnAction(e -> {
			card1 = (int) (Math.random() * (51));
			card2 = (int) (Math.random() * (51));
			card3 = (int) (Math.random() * (51));
			card4 = (int) (Math.random() * (51));

			pane.getChildren().remove(v1);
			pane.getChildren().remove(v2);
			pane.getChildren().remove(v3);
			pane.getChildren().remove(v4);

			pane.add(new ImageView(us[card1]), 0, 1);
			pane.add(new ImageView(us[card2]), 1, 1);
			pane.add(new ImageView(us[card3]), 2, 1);
			pane.add(new ImageView(us[card4]), 3, 1);

			text.setText(""); // ��������

		});

		verify = new Button("Verify");
		// �ж��Ƿ�Ϊ 24��
		verify.setOnAction(e -> {
			is24 judge = new is24();
			if (text.getText() != null) {
				if (judge.result(text.getText()) == 24) {
					Alert information = new Alert(Alert.AlertType.INFORMATION,
							"Correct!");
					information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
					information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
					information.show();
				} else if (judge.result(text.getText()) != 24) {
					Alert information = new Alert(Alert.AlertType.INFORMATION,
							"InCorrect!");
					information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
					information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
					information.show();
				} else {
					Alert information = new Alert(Alert.AlertType.INFORMATION,
							"The numbers do not match in the set!");
					information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
					information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
					information.show();
				}
			}
			// �ж��Ƿ�Ϊ�գ�
			else {
				Alert information = new Alert(Alert.AlertType.INFORMATION, "��");
				information.setTitle("information"); // ���ñ��⣬������Ĭ�ϱ���Ϊ�������Ե�information
				information.setHeaderText("Information"); // ����ͷ���⣬Ĭ�ϱ���Ϊ�������Ե�information
				information.show();
			}
		});
		refesh.setFont(new Font("Arial", 15));
		verify.setFont(new Font("Arial", 15));
		refesh.setTextFill(Color.web("#0076a3"));
		verify.setTextFill(Color.web("#0076a3"));
		label = new Label("Expression:");
		text = new TextField();
		label.setFont(new Font(13));
		v1 = new ImageView(us[card1]);
		v2 = new ImageView(us[card2]);
		v3 = new ImageView(us[card3]);
		v4 = new ImageView(us[card4]);
		pane.add(refesh, 2, 0);
		pane.add(v1, 0, 1);
		pane.add(new ImageView(us[card2]), 1, 1);
		pane.add(new ImageView(us[card3]), 2, 1);
		pane.add(new ImageView(us[card4]), 3, 1);
		pane.add(label, 0, 2);
		pane.add(text, 1, 2);
		pane.add(verify, 2, 2);
		pane.setAlignment(Pos.CENTER);
		pane.setHgap(50);
		pane.setVgap(20);
		Scene scene = new Scene(pane, 700, 500);
		scene.getStylesheets().add(
				isTwentyFourGame.class.getResource("back/cardback.css")
						.toExternalForm());
		stage.setTitle("24����Ϸ");
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) throws Exception {
		Application.launch(args);
	}
}
