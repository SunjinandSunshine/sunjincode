package version3;

import java.util.ArrayList;

/**
 * 
 * @author SUNJIN
 *
 */

public class FindAllSolutions {

	
	static Object[] tmp = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1, 2, 3,
			4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
			11, 12, 13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };

	static ArrayList<Object[]> result;

	static double count;

	public FindAllSolutions() {

	}

	public static void main(String[] args) {

		result = CombinationSelect.cmn(tmp, 4);
		long starttime = System.currentTimeMillis();
		System.out.println("Totol number of conbination is " + result.size());

		for (int i = 0; i < result.size(); i++) {

			int n1 = Integer.parseInt(result.get(i)[0] + "");
			int n2 = Integer.parseInt(result.get(i)[1] + "");
			int n3 = Integer.parseInt(result.get(i)[2] + "");
			int n4 = Integer.parseInt(result.get(i)[3] + "");

			if (JudgeIsTwentyFour.sequence(n1, n2, n3, n4) == 1) {

				count++;
			}
		}

		double rate;
		
		long endtime = System.currentTimeMillis();

		rate = count / result.size();

		System.out.println("Totol number of conbination with solution is "
				+ (int) count);

		System.out.println("Totol  solution  tatio is " + rate);

		System.out.println("The time is " + (endtime - starttime) / 1000
				+ " seconds.");

	}
}
