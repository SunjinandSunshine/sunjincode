package version3;

/**
 * 
 * @author SUNJIN
 *
 */

public class JudgeIsTwentyFour {

	// private static double expressionResult = 24;

	/** cal24()��������Ϊ24�ı���ʽ */
	JudgeIsTwentyFour() {

	}

	public static int sequence(double a, double b, double c, double d) {
		double[][] allCombinations = { { a, b, c, d }, { d, a, b, c },
				{ c, d, a, b }, { b, c, d, a }, { a, b, d, c }, { c, a, b, d },
				{ d, c, a, b }, { b, d, c, a }, { a, d, c, b }, { b, a, d, c },
				{ c, b, a, d }, { d, c, b, a }, { a, c, b, d }, { d, a, c, b },
				{ b, d, a, c }, { c, b, d, a }, { b, a, c, d }, { d, b, a, c },
				{ c, d, b, a }, { a, c, d, b }, { a, d, b, c }, { c, a, d, b },
				{ b, c, a, d }, { d, b, c, a } };
		// ��һ�������4��
		for (int mark1 = 1; mark1 <= 4; mark1++) {
			// �ڶ��������4��
			for (int mark2 = 1; mark2 <= 4; mark2++) {
				// �����������4��
				for (int mark3 = 1; mark3 <= 4; mark3++) {
					for (double[] cardNums : allCombinations) {
						// ���ּ���˳������
						for (int type = 1; type <= 5; type++) {
							double result = 0;
							switch (type) {
							case 1:
								// ((a mark1 b)mark2 c) mark3 d ��ʽ
								result = calculate(
										calculate(
												calculate(cardNums[0],
														cardNums[1], mark1),
												cardNums[2], mark2),
										cardNums[3], mark3);
								if (result == 24) {
									return 1;
								}
								break;
							case 2:
								// (a mark1 b)mark2 (c mark3 d )��ʽ
								result = calculate(
										calculate(cardNums[0], cardNums[1],
												mark1),
										calculate(cardNums[2], cardNums[3],
												mark3), mark2);
								if (result == 24) {
									return 1;
								}
								break;

							case 3:
								// (a mark1 (b mark2 c)) mark3 d ��ʽ
								result = calculate(
										calculate(
												cardNums[0],
												calculate(cardNums[1],
														cardNums[2], mark2),
												mark1), cardNums[3], mark3);
								if (result == 24) {
									return 1;
								}
								break;
							case 4:
								// a mark1 ((b mark2 c) mark3 d) ��ʽ
								result = calculate(
										cardNums[0],
										calculate(
												calculate(cardNums[1],
														cardNums[2], mark2),
												cardNums[3], mark3), mark1);
								if (result == 24) {
									return 1;
								}
								break;
							case 5:
								// a mark1 (b mark2 (c mark3 d)) ��ʽ
								result = calculate(
										cardNums[0],
										calculate(
												cardNums[1],
												calculate(cardNums[2],
														cardNums[3], mark3),
												mark2), mark1);
								if (result == 24) {
									return 1;
								}
								break;
							default:
								break;
							}
						}
					}
				}
			}
		}
		return 0;
	}

	public static double calculate(double first, double second, int markType) {
		switch (markType) {
		case 1:
			return first + second;
		case 2:
			return first - second;
		case 3:
			return first * second;
		case 4:
			return first / second;
		default:
			return 0;
		}
	}

	// public static boolean f24(double x1, double x2, double x3, double x4) {
	// LinkedList<Double> L = new LinkedList<Double>();
	// L.add(x1);
	// L.add(x2);
	// L.add(x3);
	// L.add(x4);
	// double[] a = new double[4];
	// LinkedList<Double> L1 = new LinkedList<Double>();
	// LinkedList<Double> L2 = new LinkedList<Double>();
	// LinkedList<Double> L3 = new LinkedList<Double>();
	// boolean flag = true;
	// for (int i = 0; i < 4; ++i) {
	// a[0] = L.get(i);
	// L1.clear();
	// L1.addAll(L);
	// L.remove(i);
	// for (int j = 0; j < 3; ++j) {
	// a[1] = L.get(j);
	// L2.clear();
	// L2.addAll(L);
	// L.remove(j);
	// for (int k = 0; k < 2; ++k) {
	// a[2] = L.get(k);
	// L3.clear();
	// L3.addAll(L);
	// L.remove(k);
	// for (int m = 0; m < 1; ++m) {
	// a[3] = L.get(m);
	// for (int n1 = 0; n1 < 4; n1++)
	// for (int n2 = 0; n2 < 4; ++n2)
	// for (int n3 = 0; n3 < 4; ++n3) {
	// double x = 0, y = 0, z = 0;
	// switch (n1) {
	// case 0:
	// x = a[0] + a[1];
	// break;
	// case 1:
	// x = a[0] - a[1];
	// break;
	// case 2:
	// x = a[0] * a[1];
	// break;
	// case 3:
	// try {
	// x = a[0] / a[1];
	// } catch (Exception e) {
	// System.out.println("����Ϊ0");
	// }
	// break;
	// }
	// switch (n2) {
	// case 0:
	// y = x + a[2];
	// break;
	// case 1:
	// y = x - a[2];
	// break;
	// case 2:
	// y = x * a[2];
	// break;
	// case 3:
	// try {
	// y = x / a[2];
	// } catch (Exception e) {
	// System.out.println("����Ϊ0");
	// }
	// break;
	// }
	// switch (n3) {
	// case 0:
	// z = y + a[3];
	// break;
	// case 1:
	// z = y - a[3];
	// break;
	// case 2:
	// z = y * a[3];
	// break;
	// case 3:
	// try {
	// z = y / a[3];
	// } catch (Exception e) {
	// System.out.println("����Ϊ0");
	// }
	// break;
	// }
	// if (z == 24d) {
	// // System.out.println(a[0] + s[n1] +
	// // a[1]
	// // + s[n2] + a[2] + s[n3] + a[3]
	// // + "=" + "24");
	// flag = false;
	// }
	// }
	//
	// }
	// L.clear();
	// L.addAll(L3);
	// }
	// L.clear();
	// L.addAll(L2);
	// }
	// L.clear();
	// L.addAll(L1);
	// }
	// if (flag)
	// return false;
	// else
	// return true;
	// }
}
